import HomeBanner from "../../Components/HomeBanner";

const Home = ()=>{
    return (
        <>
           <HomeBanner/>
        </>
    )
}
export default Home;